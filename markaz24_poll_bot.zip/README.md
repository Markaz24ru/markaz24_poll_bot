# Markaz24 So'rovnoma Bot

Bu Telegram bot `@markaz24uz` kanaliga obuna bo‘lgan foydalanuvchilardan:
- Telefon raqamini talab qiladi
- CAPTCHA kod orqali robot emasligini tekshiradi
- So‘rovnoma savoliga rasm bilan birga ovoz berish imkonini beradi
- Har bir ovozni maxsus guruhga yuboradi

## Foydalanish

### 1. Klonlash va o‘rnatish

```bash
git clone https://github.com/YOUR_USERNAME/markaz24_poll_bot.git
cd markaz24_poll_bot
pip install -r requirements.txt
```

### 2. .env faylni sozlash

`.env` fayl ichida bot tokenini yozing:

```
BOT_TOKEN=YOUR_BOT_TOKEN
```

(Misol: `BOT_TOKEN=7906375997:AAEAKxtY06R-wGIAnOwj2eP75JCPQ_b-2SQ`)

### 3. Botni ishga tushirish

```bash
python main.py
```

## Texnologiyalar
- Python 3.7+
- Aiogram
- Dotenv
